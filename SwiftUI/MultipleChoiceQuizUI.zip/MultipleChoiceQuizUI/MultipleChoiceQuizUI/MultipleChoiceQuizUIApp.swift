//
//  MultipleChoiceQuizUIApp.swift
//  MultipleChoiceQuizUI
//
//  Created by gnksbm on 2023/06/21.
//

import SwiftUI

@main
struct MultipleChoiceQuizUIApp: App {
    
    init() {
        Thread.sleep(forTimeInterval: 0.7)
        }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
