//
//  ShoppingBasketUIApp.swift
//  ShoppingBasketUI
//
//  Created by gnksbm on 2023/08/04.
//

import SwiftUI

@main
struct ShoppingBasketUIApp: App {
    @State var string = "First"
    var body: some Scene {
        WindowGroup {
            ContentView()
//            ContentView(binding: $string)
        }
    }
}
